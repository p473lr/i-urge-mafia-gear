// Read a QweRty code, and print its message
/*
##############    ####  ######        ######  ##    ##############
##          ##  ##  ##  ##          ##  ##      ##  ##          ##
##  ######  ##    ##    ##    ##  ##########  ##    ##  ######  ##
##  ######  ##    ######  ####    ##  ##  ########  ##  ######  ##
##  ######  ##  ##  ##  ##  ##  ##  ##  ####    ##  ##  ######  ##
##          ##  ##  ##  ##  ##      ##  ##  ######  ##          ##
##############  ##  ##  ##  ##  ##  ##  ##  ##  ##  ##############
                  ##                  ##  ##  ##                  
            ##  ##  ##  ##    ########  ####  ##        ##  ####  
                ####        ########    ####    ####  ##  ######  
          ########      ##      ##  ##          ####    ####      
              ######  ##  ##  ######  ##  ##          ##  ##    ##
            ##      ############  ##  ##  ##  ##          ##    ##
                ####  ####  ##  ##  ##      ##      ######  ####  
            ######  ##  ##  ##########  ##      ##    ####    ####
          ##          ##      ##  ##  ##  ##      ##  ##  ####  ##
            ########  ##    ####  ####              ##      ####  
                ##    ######  ##  ######  ##      ######    ######
            ####        ##      ##  ##            ##  ####        
              ##  ##  ##  ##  ##  ##  ##  ######              ####
            ####  ##  ##  ##  ##########      ##  ####        ##  
                  ####      ##  ##    ################  ##    ##  
            ##  ##    ########  ######      ##    ####  ####  ####
              ##  ##      ##  ##  ##          ##      ##        ##
            ####          ####        ######  ############  ####  
                      ##    ##    ##  ##      ####      ##    ####
##############              ##              ##  ##  ##  ##      ##
##          ##    ######  ##  ##  ##    ####  ####      ##########
##  ######  ##    ##  ##  ######  ##  ######################  ##  
##  ######  ##  ##########      ##  ##  ######          ##  ##  ##
##  ######  ##    ####      ##          ##  ####  ##########  ##  
##          ##        ##  ##  ##  ##      ##    ####  ######    ##
##############  ##          ##  ##  ##      ##        ####  ####  

*/

#include <string>
#include <iostream>

using namespace std;

#define MAX_KEEPOUTS 6

char grid[200][200];  // Should be enough characters to hold the grid
int cols, rows;
char message[400];

struct block
{
	int rowmin;
	int rowmax;
	int colmin;
	int colmax;
};
block keepout[MAX_KEEPOUTS];

void printGrid(void)
{
	int i,j;
	cout<<endl<<"QweRty Code in memory with Keepouts:"<<endl;
	for(i=0;i<rows;i++)
	{
		for(j=0;j<cols;j++)
		{
			cout<< (grid[i][j]<0? '.' : (grid[i][j]==1?'#':(grid[i][j]==0?' ':'x')));
		}
		cout<<endl;
	}
}

// Set Keepouts
// Top-Left, Top-Right, Bottom-Left, Bottom-Right, Top-Line, Left-Line
void setKeepouts(void)
{
	int i,j,k;
	// 0: Top-Left is always the same (8 Rows: 7hash+1space. 16 Cols:14hash+2spaces)
	keepout[0].rowmin=0; keepout[0].colmin=0; keepout[0].rowmax=7; keepout[0].colmax=15;
	// 1: Top-Right is the same distance from right (8 Rows: 7hash+1space. 16 Cols:2spaces+14hash)
	keepout[1].rowmin=0; keepout[1].colmin=cols-16; keepout[1].rowmax=7; keepout[1].colmax=cols-1;
	// 2: Bottom-Left is always the same count up (8 Rows: 1space+7hash. 16 Cols:14hash+2spaces)
	keepout[2].rowmin=rows-8; keepout[2].colmin=0; keepout[2].rowmax=rows-1; keepout[2].colmax=15;
	// 3: Bottom-Right min is ID'd from other corners. Max is four lines greater, 9cols greater
	keepout[3].rowmin=keepout[2].rowmin-1; keepout[3].rowmax=keepout[3].rowmin+4;
	keepout[3].colmin=keepout[1].colmin-1; keepout[3].colmax=keepout[3].colmin+9;
	// 4: Top-Line - always row 6
	keepout[4].rowmin=keepout[4].rowmax=6; keepout[4].colmin=0; keepout[4].colmax=cols-1;
	// 5: Left-Line - always columns 12 and 13
	keepout[5].rowmin=0; keepout[5].rowmax=rows-1; keepout[5].colmin=12; keepout[5].colmax=13;

	// Scan grid and mark grid with -1 (keepout)
	for (i=0;i<rows;i++)
		for (j=0;j<cols;j++)
		{
			for(k=0;k<MAX_KEEPOUTS;k++)
			{
				if( (i>=keepout[k].rowmin) && (i<=keepout[k].rowmax) &&
					(j>=keepout[k].colmin) && (j<=keepout[k].colmax) )
					grid[i][j]=-1;
			}
		}
}

void fillMessage(void)
{
	char currentByte=0;
	int currentBit;
	int messageIndex=0;
	int bitCount=0;
	int searchDir;
	int row,col;
	
	// Start at Bottom-Right.  Scan up and down, moving left.
	row = rows-1;
	col = cols-1;
	searchDir = -1; // Start moving up

	while (col >= 0)
	{
		currentBit = grid[row][col];
		if (currentBit >= 0)
		{
			currentByte = (currentByte*2)+currentBit;
			bitCount++;
			if (bitCount==8)
			{
				message[messageIndex++]=currentByte; // Add the byte to the message
				currentByte=bitCount=0;
			}
		}
		// move to next location.  Every pair of columns is identical, so move 2 columns.
		row +=searchDir;
		if(row < 0) //Move to next column and move up
		    {col-=2; row=0; searchDir=1;}
		else if (row==rows)//Move to next column and move down
			{col-=2; row=rows-1; searchDir=-1;}
	}
}

int main( int argc, char* argv[] )
{
   int i, j;
   char m;
   bool gridDone;

   while(1){
	    memset(keepout,0,MAX_KEEPOUTS*sizeof(block));
		memset(message,0,sizeof(message));
   i=j=cols=rows=0; 
   gridDone=false;
   cout << "Enter QweRty Code (Q to quit):" << endl;
   while (!gridDone)
   {
		m=getchar(); 
		if((m=='Q')||(m=='q'))
			return 0;
		else if(m=='\n') //End of line
		{
			if (j>2) { // Avoid any extra CR lines
				if (cols==0) cols=j; // Set max column count
				i++; // Next Row
				if(i==(cols/2)){
					gridDone=true;
					rows=i; // Max rows
				}
				j=0; // Back to col 0
			}
		}
		else if(m=='0') //My own termination character
		{
			if (cols>2) { // Only look for termination after analyzing a line
				rows = i; // Set max row count
				gridDone=true;
			}
		}
		else
			grid[i][j++]=(m=='#'? 1 : 0); // Store character into grid
   }
   setKeepouts();
   //printGrid();
   fillMessage();
   cout << message << endl; // Print the message
   }
}

