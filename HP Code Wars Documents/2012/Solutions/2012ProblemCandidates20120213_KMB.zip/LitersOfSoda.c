#include <stdio.h>
#include <math.h>
main(){
 int l;
 scanf("%d",&l);
 printf("%d\n",(int)round((double)l/3.785));
 }
